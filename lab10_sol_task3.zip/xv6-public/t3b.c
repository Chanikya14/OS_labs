#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[]) {

    int N = 5;
    int orig=getpid();
    scheduler_on();
    for(int i=0;i<N;i++){
        if(fork()==0){
            printf(1,"Child Process: %d\n",getpid());
            sleep(10);
        }else{
            printf(1,"Parent Process: %d\n",getpid());
            break;
        }
    }
    wait();
    sleep(10);
    if(orig==getpid()){
        scheduler_off();
    }
    exit();
}