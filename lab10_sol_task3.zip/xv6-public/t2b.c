#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

static unsigned int seed = 1;
void srand(unsigned int s) {
    seed = s;
}
int rand() {
    seed = seed * 1664525 + 1013904223;
    return (seed >> 16) & 0x7FFFFFFF;
}


void work(int proc_num){
    unsigned int current_time = uptime();
    srand(current_time);
    int sleepTime = rand() % 6;
    sleepTime = sleepTime < 5 ? sleepTime : 5;

    printf(1,"Section 1 of code | Process Number: %d | Sleep Time: %d\n",proc_num, sleepTime);
    barrier();
    sleep(sleepTime);
    printf(1,"Section 2 of code | Process Number: %d | Sleep Time: %d\n",proc_num, sleepTime);
    exit();
}

int main(int argc, char *argv[]) {

    int N = 5;

    barrier_init(N);

    for(int i=0;i<N;i++) {
        int retVal = fork();
        if (retVal == 0)
          work(i+1);
    }
    for(int i=0;i<N;i++)
        wait();
    

    printf(1, "All children cleaned\n");
    exit();
}