#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

void work(int proc_num){
    printf(1,"Section 1 of code | Process Number: %d\n",proc_num);
    barrier();
    sleep(1);
    printf(1,"Section 2 of code | Process Number: %d\n",proc_num);
    exit();
}

int main(int argc, char *argv[]) {

    int N = 5;

    barrier_init(N);

    for(int i=0;i<N;i++) {
        int retVal = fork();
        if (retVal == 0)
          work(i+1);
    }
    for(int i=0;i<N;i++)
        wait();
    

    printf(1, "All children cleaned\n");
    exit();
}