#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
    printf(1, "Test spage\n");

    char* va1 = spage();
    printf(1, "VA: 0x%x ==> PA: %d\n", va1, v2p((int)va1));
    *va1 = 5;
    printf(1, "Write[0x%x] = %d\n", va1, *va1);
    
    char* va2 = spage2((int)(va1));
    printf(1, "VA: 0x%x ==> PA: %d\n", va2, v2p((int)va2));
    printf(1, "Read[0x%x] = %d\n", va2, *va2);

    *(va2 + 1) = 10;
    printf(1, "Write[0x%x] = %d\n", va2+1, *(va2+1));

    printf(1, "Read[0x%x] = %d\n", va1+1, *(va1+1));

    // printf(1, "Free: %d\n", sfree((int)va2) );

    exit();
}
