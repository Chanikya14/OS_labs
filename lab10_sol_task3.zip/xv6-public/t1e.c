#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
    int pid = fork();
    if(pid == 0)
    {
        int a = 0;
        a++;
        char* va1 = spage();
        printf(1, "Child pid: %d | VA: 0x%x ==> PA: 0x%x\n", getpid(), va1, (char*)v2p((int)va1));
        *va1 = 5;
        printf(1, "Child pid: %d | Write[0x%x] = %d\n", getpid(), va1, *va1);

        char* va2 = spage2((int)(va1));
        printf(1, "Child pid: %d | VA: 0x%x ==> PA: 0x%x\n", getpid(), va2, (char*)v2p((int)va2));
        printf(1, "Child pid: %d | Read[0x%x] = %d\n", getpid(), va2, *va2);
        exit();
    }
        wait();
        char* va1 = spage();
        printf(1, "Parent pid: %d | VA: 0x%x ==> PA: 0x%x\n", getpid(), va1, (char*)v2p((int)va1));
        *va1 = 5;
        printf(1, "Parent pid: %d | Write[0x%x] = %d\n", getpid(), va1, *va1);
    
        char* va2 = spage2((int)(va1));
        printf(1, "Parent pid: %d | VA: 0x%x ==> PA: 0x%x\n", getpid(),va2, (char*)v2p((int)va2));
        printf(1, "Parent pid: %d | Read[0x%x] = %d\n", getpid(), va2, *va2);

    exit();
}
