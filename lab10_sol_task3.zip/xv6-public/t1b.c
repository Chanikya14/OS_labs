#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
    char* va1 = spage();
    printf(1, "VA: 0x%x ==> PA: 0x%x\n", va1, (char*)v2p((int)va1));
    *va1 = 5;
    printf(1, "Write[0x%x] = %d\n", va1, *va1);
    
    char* va2 = spage2((int)(va1));
    printf(1, "VA: 0x%x ==> PA: 0x%x\n", va2, (char*)v2p((int)va2));
    printf(1, "Read[0x%x] = %d\n", va2, *va2);

    *(va2 + 1) = 10;
    printf(1, "Write[0x%x] = %d\n", va2+1, *(va2+1));

    printf(1, "Read[0x%x] = %d\n", va1+1, *(va1+1));

    exit();
}
