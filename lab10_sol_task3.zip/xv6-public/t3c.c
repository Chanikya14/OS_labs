#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[]) {

    int N = 3;

    int orig=getpid();
    
    int a=fork();
    int b=fork();
    sleep(10);
    
    scheduler_on();

    if(a==0){
        if(b==0){
            
            for(int i=0;i<2*N;i++){

                printf(1,"Subsection: 1, Loop Iteration: %d\n",i+1);
                sleep(10);
            }

        }else{
            
            for(int i=0;i<2*N;i++){

                printf(1,"Subsection: 2, Loop Iteration: %d\n",i+1);
                sleep(10);
            }
        }
    }else{
        if(b==0){
            
            for(int i=0;i<3*N;i++){

                printf(1,"Subsection: 3, Loop Iteration: %d\n",i+1);
                sleep(10);
            }
        }else{
            for(int i=0;i<N;i++){

                printf(1,"Subsection: 4, Loop Iteration: %d\n",i+1);
                sleep(10);
            }
        }                
    }
    wait();
    wait();
    wait();
    if(orig==getpid()){
        scheduler_off();
    }
    exit();
}