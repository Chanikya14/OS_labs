#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

int main() {
    int parentid = getpid();
    int rc = fork();
  
    if(rc==0) { // child
        printf("Child : My process ID is:%d \n",(int) getpid());
        printf("Child : The parent process ID is:%d\n",parentid);
        sleep(5);
        printf("\nChild: After sleeping for 5 seconds\n");
        printf("Child : My process ID is:%d \n",(int) getpid());
        printf("Child : The parent process ID is:%d\n",getppid());
    }
    else {
        printf("Parent: My process ID is:%d \n",(int) getpid());
        printf("Parent: The child process ID is:%d\n",rc);
    }
    return 0;
}