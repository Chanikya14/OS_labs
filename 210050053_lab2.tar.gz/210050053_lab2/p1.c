#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>

int main() {
    int parentid = getpid();
    int rc = fork();
  
    if(rc==0) { // child
        printf("Child : My process ID is:%d \n",(int) getpid());
        printf("Child : The parent process ID is:%d\n",parentid);
    }
    else {
        printf("Parent: My process ID is:%d \n",(int) getpid());
        printf("Parent: The child process ID is:%d\n",rc);
    }
    return 0;
}