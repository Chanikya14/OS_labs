#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

int main(int argc,char *argv[]){
    char pname[50],s[] = "./";
   {
    int a;
    printf("Process A: Input value of x :");
    scanf("%d", &a);
    int buff[1] = {a};
    int fd[2];
    pipe(fd);
    write(fd[1],buff,4);
    int rc = fork();
    if(rc==0) {
        int b;
        int buffer[1];
        printf("Process B: Input value of x :");
        scanf("%d",&b);
        read(fd[0],buffer,4);
        buffer[0] += b;
        write(fd[1],buffer,4);
    }
    else {
        wait(NULL);
        int nwbuffer[1];
        read(fd[0],nwbuffer,4);
        printf("Process A: Result after addition : %d\n",nwbuffer[0]);
    }
   }
    return 0;
}