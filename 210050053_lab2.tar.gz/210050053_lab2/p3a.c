#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<time.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc,char *argv[]){
    
    printf("Print statement before exec\n");
    char *myargs[2];
    char pname[50];
    scanf("%[^\n]%*c", pname);
    myargs[0] = pname;
    myargs[1] = NULL;
    execv(myargs[0],myargs); 
    // for execv, we have to provide full path if the executable file is not present in the same directory
    // for execvp, we can just provide the name of the executable file, it will search in PATH env variable and execute it
    // Do exec here
    

    printf("Print statement after exec. This should never print\n");
    
    
    return 0;
}