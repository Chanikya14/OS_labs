#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

int main(int argc,char *argv[]){
    char pname[50],s[] = "./";
   while(1){
    printf(">>> ");
    scanf("%[^\n]%*c", pname);
    
    int rc = fork();
    if(rc==0) {
        char* myargs[2];
        myargs[0] = pname;
        myargs[1] = NULL;
        
        execv(myargs[0],myargs);
    }
    else {
        wait(NULL);
    }
   }
    // Do exec here
    

    printf("Print statement after exec. This should never print\n");
    
    
    return 0;
}