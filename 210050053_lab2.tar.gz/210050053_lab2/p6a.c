#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

void func(int parent,int n) {
    if(n<0) {
        return;
    }
    int rc = fork();
    
    if(rc==0) {
        func((int)getpid(),n-1);
    }
    else {
        printf("Child %d is created\n",rc);
        wait(NULL);
        printf("Child %d with parent %d exited\n",rc,parent);
    }
}

int main() {
    int n;
    scanf("%d",&n);
    int id = getpid();
    printf("Parent is : %d\n",id);
    printf("Number of Children: %d\n",n);
    int rc = fork();

    if(rc==0) {
        func((int)getpid(),n-1);
    }
    else {
        printf("Child %d is created\n",rc);
        wait(NULL);
        printf("Child %d with parent %d exited\n",rc,id);
        printf("Parent exited\n");
    }
    return 0;
}