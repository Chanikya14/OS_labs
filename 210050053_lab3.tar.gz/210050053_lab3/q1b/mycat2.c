#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
int main(){
    int fd=0;
    int fd2 = 1;
    char character;
    while(read(fd,&character, sizeof(char)) >0 )
    	write(fd2,&character, sizeof(char));
}