#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
int main(){
    int dread = open("in.txt",O_RDONLY);
    int dwrite = open("out.txt",O_WRONLY|O_CREAT,00700);    
    dup2(dread,0);
    dup2(dwrite,1);
    char character;
    while(read(0,&character, sizeof(char)) >0 )
    	write(1,&character, sizeof(char));
    close(dread);
    close(dwrite);
} 