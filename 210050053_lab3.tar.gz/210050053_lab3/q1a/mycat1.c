#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
int main(){
    int fd = open("in.txt",O_RDONLY);
    if(fd==-1) {
        perror("Failed to open the file");
        return 1;
    }
    int fd2 = open("out.txt",O_WRONLY|O_CREAT,00700);
    char character;
    while(read(fd,&character, sizeof(char)) >0 )
    	write(fd2,&character, sizeof(char));
    close(fd);
    close(fd2);
}